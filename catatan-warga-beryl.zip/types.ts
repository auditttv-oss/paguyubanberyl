export type OccupancyStatus = 'Menetap' | 'Penyewa' | 'Kunjungan' | 'Ditempati 2026';

export interface Resident {
  id: string;
  fullName: string;
  blockNumber: string; // Blok & No. Rumah
  whatsapp: string;
  occupancyStatus: OccupancyStatus;
  monthlyDuesPaid: boolean; // Iuran Wajib 10.000
  eventDuesAmount: number; // Iuran Acara (Sukarela)
  notes: string;
  updatedAt: number;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  date: number;
  category: 'Operasional' | 'Acara' | 'Lainnya';
}

export interface FinancialSummary {
  totalResidents: number;
  totalMonthlyDues: number;
  totalEventDues: number;
  totalExpenses: number;
  balance: number;
}

export enum TabView {
  DASHBOARD = 'DASHBOARD',
  RESIDENTS = 'RESIDENTS',
  EXPENSES = 'EXPENSES',
}