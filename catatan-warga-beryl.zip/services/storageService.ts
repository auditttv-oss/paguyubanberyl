import { Resident, Expense } from '../types';

const RESIDENTS_KEY = 'beryl_residents_v1';
const EXPENSES_KEY = 'beryl_expenses_v1';

// Initial Mock Data to populate if empty
const MOCK_RESIDENTS: Resident[] = [
  {
    id: '1',
    fullName: 'Budi Santoso',
    blockNumber: 'A1-05',
    whatsapp: '08123456789',
    occupancyStatus: 'Menetap',
    monthlyDuesPaid: true,
    eventDuesAmount: 50000,
    notes: 'Sudah lunas semua',
    updatedAt: Date.now(),
  },
  {
    id: '2',
    fullName: 'Siti Aminah',
    blockNumber: 'B2-10',
    whatsapp: '08987654321',
    occupancyStatus: 'Penyewa',
    monthlyDuesPaid: true,
    eventDuesAmount: 0,
    notes: 'Janji bayar acara minggu depan',
    updatedAt: Date.now(),
  },
];

export const getResidents = (): Resident[] => {
  try {
    const data = localStorage.getItem(RESIDENTS_KEY);
    if (!data) {
      localStorage.setItem(RESIDENTS_KEY, JSON.stringify(MOCK_RESIDENTS));
      return MOCK_RESIDENTS;
    }
    
    // Migration logic for old data format
    const parsedData = JSON.parse(data);
    return parsedData.map((item: any) => {
      // Migrate event dues
      const eventDuesAmount = item.eventDuesAmount !== undefined 
        ? item.eventDuesAmount 
        : (item.eventDuesPaid ? 50000 : 0);

      // Migrate status
      let occupancyStatus = item.occupancyStatus;
      if (occupancyStatus === 'Pemilik') occupancyStatus = 'Menetap';
      if (occupancyStatus === 'Kosong') occupancyStatus = 'Ditempati 2026';

      return {
        ...item,
        eventDuesAmount,
        occupancyStatus
      };
    });
  } catch (error) {
    console.error("Error reading residents", error);
    return [];
  }
};

export const saveResidents = (residents: Resident[]) => {
  localStorage.setItem(RESIDENTS_KEY, JSON.stringify(residents));
};

export const getExpenses = (): Expense[] => {
  try {
    const data = localStorage.getItem(EXPENSES_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error("Error reading expenses", error);
    return [];
  }
};

export const saveExpenses = (expenses: Expense[]) => {
  localStorage.setItem(EXPENSES_KEY, JSON.stringify(expenses));
};