export const MONTHLY_DUES_AMOUNT = 10000;
// EVENT_DUES_AMOUNT removed as it is now voluntary/variable

export const OCCUPANCY_OPTIONS = [
  { value: 'Menetap', label: 'Menetap' },
  { value: 'Penyewa', label: 'Penyewa' },
  { value: 'Kunjungan', label: 'Kunjungan' },
  { value: 'Ditempati 2026', label: 'Ditempati 2026' },
];

export const APP_TITLE = "Catatan Warga Beryl";
export const APP_SUBTITLE = "Perumahan Cluster Beryl PMM Curug Badak Maja Lebak";