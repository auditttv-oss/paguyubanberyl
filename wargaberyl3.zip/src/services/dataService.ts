import { supabase } from '../supabaseClient';
import { Resident, Expense, Payment, Comment } from '../types';
import * as XLSX from 'xlsx';
import { GoogleGenerativeAI } from "@google/generative-ai";

// ==================== HELPER ====================
const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

const dateToTimestamp = (d: string): number => new Date(d).getTime();
const timestampToDate = (t: number): string => new Date(t).toISOString().split('T')[0];

// ==================== CRUD WARGA ====================
export const fetchResidents = async (): Promise<Resident[]> => {
  const { data, error } = await supabase.from('residents').select('*').order('block_number');
  if (error) throw error;
  return (data || []).map((r: any) => ({
    id: r.id, fullName: r.full_name, blockNumber: r.block_number, whatsapp: r.whatsapp,
    occupancyStatus: r.occupancy_status, eventDuesAmount: Number(r.event_dues_amount) || 0,
    notes: r.notes || '', updatedAt: r.updated_at
  }));
};

export const fetchResidentsWithStatus = async (m: number, y: number): Promise<Resident[]> => {
  const { data: res, error: re } = await supabase.from('residents').select('*').order('block_number');
  if (re) throw re;
  const { data: pay, error: pe } = await supabase.from('monthly_payments').select('resident_id').eq('month', m).eq('year', y);
  const paidIds = new Set((pay || []).map(p => p.resident_id));
  return res.map((r: any) => ({
    id: r.id, fullName: r.full_name, blockNumber: r.block_number, whatsapp: r.whatsapp,
    occupancyStatus: r.occupancy_status, eventDuesAmount: Number(r.event_dues_amount) || 0,
    notes: r.notes || '', updatedAt: r.updated_at, isPaidCurrentMonth: paidIds.has(r.id)
  }));
};

export const createResident = async (r: any) => {
  await supabase.from('residents').insert([{
    full_name: r.fullName, block_number: r.blockNumber, whatsapp: r.whatsapp,
    occupancy_status: r.occupancyStatus, event_dues_amount: Number(r.eventDuesAmount),
    notes: r.notes, updated_at: Date.now()
  }]);
};

export const updateResident = async (r: any) => {
  await supabase.from('residents').update({
    full_name: r.fullName, block_number: r.blockNumber, whatsapp: r.whatsapp,
    occupancy_status: r.occupancyStatus, event_dues_amount: Number(r.eventDuesAmount),
    notes: r.notes, updated_at: Date.now()
  }).eq('id', r.id);
};

export const deleteResident = async (id: string) => {
  await supabase.from('residents').delete().eq('id', id);
};

// ==================== CRUD PENGELUARAN ====================
export const fetchExpenses = async (): Promise<Expense[]> => {
  const { data, error } = await supabase.from('expenses').select('*').order('date', { ascending: false });
  if (error) throw error;
  return (data || []).map((e: any) => ({
    id: e.id, description: e.description, amount: Number(e.amount),
    date: timestampToDate(e.date), category: e.category, receiptUrl: e.receipt_url
  }));
};

export const createExpense = async (e: any) => {
  await supabase.from('expenses').insert([{
    description: e.description, amount: Number(e.amount), date: dateToTimestamp(e.date),
    category: e.category, receipt_url: e.receiptUrl || ''
  }]);
};

export const deleteExpense = async (id: string) => {
  await supabase.from('expenses').delete().eq('id', id);
};

export const updateExpense = async (e: any) => {
  await supabase.from('expenses').update({
    description: e.description, amount: Number(e.amount), date: dateToTimestamp(e.date),
    category: e.category, receipt_url: e.receiptUrl || ''
  }).eq('id', e.id);
};

// ==================== IURAN & LAINNYA ====================
export const fetchAllPayments = async (): Promise<Payment[]> => {
  const { data, error } = await supabase.from('monthly_payments').select('*');
  if (error) throw error;
  return (data || []).map((p: any) => ({ id: p.id, resident_id: p.resident_id, month: p.month, year: p.year, amount: p.amount, paid_at: p.paid_at }));
};

export const fetchPaymentsByMonth = async (m: number, y: number) => {
  const { data } = await supabase.from('monthly_payments').select('*').eq('month', m).eq('year', y);
  return data || [];
};

export const togglePayment = async (rid: string, m: number, y: number, status: boolean) => {
  if (status) await supabase.from('monthly_payments').insert([{ resident_id: rid, month: m, year: y, amount: 10000, paid_at: Date.now() }]);
  else await supabase.from('monthly_payments').delete().match({ resident_id: rid, month: m, year: y });
};

export const fetchComments = async () => {
  const { data } = await supabase.from('comments').select('*').order('created_at', { ascending: false });
  return data || [];
};

export const createComment = async (n: string, c: string) => { await supabase.from('comments').insert([{ name: n, content: c }]); };
export const deleteComment = async (id: string) => { await supabase.from('comments').delete().eq('id', id); };

export const analyzeFinancesWithAI = async (sum: string) => {
  const key = import.meta.env.VITE_GEMINI_API_KEY;
  if (!key) return "AI Key Error";
  const genAI = new GoogleGenerativeAI(key);
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
  const result = await model.generateContent(sum);
  return result.response.text();
};

// ==================== EKSPOR EXCEL (FIX FINAL - LENGKAP 10RB & SUKARELA) ====================
export const exportDataToExcel = async () => {
  const [res, exp, pay] = await Promise.all([fetchResidents(), fetchExpenses(), fetchAllPayments()]);
  const wb = XLSX.utils.book_new();
  const currentYear = new Date().getFullYear();

  // --- SHEET 1: MASTER DATA WARGA ---
  const wsWargaData = res.map(r => ({
    'Blok': r.blockNumber,
    'Nama Lengkap': r.fullName,
    'Status': r.occupancyStatus,
    'No. WA': r.whatsapp,
    'Iuran Sukarela (Dana Acara)': r.eventDuesAmount,
    'Catatan': r.notes
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(wsWargaData), "Master Warga");

  // --- SHEET 2: REKAP IURAN BULANAN 10RB (MATRIX) ---
  const matrixData = res.map(r => {
    const row: any = { 'Blok': r.blockNumber, 'Nama': r.fullName };
    months.forEach((mName, index) => {
      const monthNum = index + 1;
      const isPaid = pay.some(p => p.resident_id === r.id && p.month === monthNum && p.year === currentYear);
      row[mName] = isPaid ? 'LUNAS (10rb)' : '-';
    });
    return row;
  });
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(matrixData), "Rekap Iuran 10rb");

  // --- SHEET 3: DATA PENGELUARAN ---
  const wsExpData = exp.map(e => ({
    'Tanggal': e.date,
    'Kategori': e.category,
    'Keterangan': e.description,
    'Nominal Keluar': e.amount
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(wsExpData), "Pengeluaran");

  // --- SHEET 4: RINGKASAN KAS ---
  const totalWajib = pay.length * 10000;
  const totalSukarela = res.reduce((s, r) => s + r.eventDuesAmount, 0);
  const totalBelanja = exp.reduce((s, e) => s + e.amount, 0);
  const summary = [
    { 'DESKRIPSI': 'TOTAL PENERIMAAN KAS WAJIB (10RB)', 'JUMLAH': totalWajib },
    { 'DESKRIPSI': 'TOTAL PENERIMAAN IURAN SUKARELA', 'JUMLAH': totalSukarela },
    { 'DESKRIPSI': 'TOTAL PENGELUARAN/BELANJA', 'JUMLAH': totalBelanja },
    { 'DESKRIPSI': 'SALDO AKHIR KAS BERYL', 'JUMLAH': (totalWajib + totalSukarela) - totalBelanja }
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(summary), "Ringkasan Saldo");

  XLSX.writeFile(wb, `LAPORAN_KEUANGAN_BERYL_LENGKAP.xlsx`);
};

export const exportDataToJSON = async () => {
  const [residents, expenses, payments, comments] = await Promise.all([fetchResidents(), fetchExpenses(), fetchAllPayments(), fetchComments()]);
  const blob = new Blob([JSON.stringify({ residents, expenses, payments, comments }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = `backup_beryl.json`; link.click();
};