import React, { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { fetchComments, createComment, deleteComment } from '../services/dataService';
import { useAuth } from '../contexts/AuthContext';
import { 
  MessageSquare, Send, Trash2, User, Loader2, 
  Cloud, Sun, CloudRain, CloudLightning, Wind, Droplets, MapPin,
  Newspaper, ExternalLink, Calendar, AlertCircle,
  RefreshCw, Clock, ThumbsUp, AlertTriangle, ChevronRight, Shield,
  Bell, EyeOff
} from 'lucide-react';

// --- WEATHER WIDGET COMPONENT ---
const WeatherWidget = () => {
  const [weather, setWeather] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchWeatherData = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=-6.33&longitude=106.40&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&timezone=Asia%2FJakarta`
      );
      const data = await response.json();
      setWeather(data.current);
    } catch (err) {
      console.error("Weather error:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWeatherData();
  }, [fetchWeatherData]);

  const getWeatherInfo = (code: number) => {
    const weatherMap: Record<number, { icon: React.ReactNode, label: string, bg: string }> = {
      0: { icon: <Sun className="w-8 h-8 md:w-10 md:h-10 text-yellow-300" />, label: 'Cerah', bg: 'from-orange-400 to-yellow-500' },
      1: { icon: <Sun className="w-8 h-8 md:w-10 md:h-10 text-yellow-200" />, label: 'Cerah Berawan', bg: 'from-blue-400 to-cyan-500' },
      3: { icon: <Cloud className="w-8 h-8 md:w-10 md:h-10 text-gray-200" />, label: 'Mendung', bg: 'from-gray-500 to-slate-600' },
      61: { icon: <CloudRain className="w-8 h-8 md:w-10 md:h-10 text-blue-200" />, label: 'Hujan Ringan', bg: 'from-indigo-500 to-blue-600' },
    };
    return weatherMap[code] || { icon: <Cloud className="w-8 h-8 md:w-10 md:h-10" />, label: 'Berawan', bg: 'from-blue-500 to-gray-500' };
  };

  const info = getWeatherInfo(weather?.weather_code || 1);

  return (
    <div className={`relative overflow-hidden rounded-[2rem] shadow-xl bg-gradient-to-br ${info.bg} text-white p-6 md:p-8 transition-all`}>
      <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="p-3 bg-white/20 backdrop-blur-md rounded-2xl">
            {loading ? <Loader2 className="w-8 h-8 animate-spin" /> : info.icon}
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest opacity-80 flex items-center gap-1"><MapPin size={10}/> Maja, Banten</p>
            <h2 className="text-4xl md:text-5xl font-black">{Math.round(weather?.temperature_2m || 0)}°C</h2>
            <p className="text-sm font-bold">{info.label}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 w-full md:w-auto">
          <div className="bg-black/10 p-3 rounded-2xl text-center border border-white/10">
            <span className="block text-lg font-black">{weather?.relative_humidity_2m || 0}%</span>
            <span className="text-[8px] uppercase font-black opacity-60">Lembab</span>
          </div>
          <div className="bg-black/10 p-3 rounded-2xl text-center border border-white/10">
            <span className="block text-lg font-black">{weather?.wind_speed_10m || 0}</span>
            <span className="text-[8px] uppercase font-black opacity-60">km/h</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- NEWS WIDGET COMPONENT (REAL-TIME UPDATED) ---
const NewsWidget = () => {
  const [news, setNews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRealNews = async () => {
    try {
      setLoading(true);
      // Menggunakan RSS Antara News via rss2json converter
      const res = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=https://www.antaranews.com/rss/top-news.xml`);
      const data = await res.json();
      setNews(data.items.slice(0, 5));
    } catch (err) {
      console.error("News fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRealNews();
  }, []);

  return (
    <div className="bg-white p-6 rounded-[2.5rem] shadow-lg border border-gray-100 flex flex-col h-full">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 text-blue-600 rounded-xl"><Newspaper size={20} /></div>
          <h3 className="font-black text-gray-800 uppercase text-xs tracking-widest">Berita Terkini</h3>
        </div>
        <button onClick={fetchRealNews} className="p-2 hover:bg-gray-100 rounded-full transition-all">
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="space-y-4 flex-1 overflow-y-auto custom-scrollbar pr-1">
        {loading ? (
          [1, 2, 3].map(i => <div key={i} className="h-20 bg-gray-50 rounded-2xl animate-pulse"></div>)
        ) : (
          news.map((item, index) => (
            <a key={index} href={item.link} target="_blank" rel="noreferrer" className="block group bg-gray-50 hover:bg-blue-50 p-4 rounded-2xl transition-all border border-transparent hover:border-blue-100">
              <h4 className="font-bold text-gray-800 group-hover:text-blue-700 text-xs leading-snug line-clamp-2 mb-2">{item.title}</h4>
              <div className="flex items-center justify-between text-[8px] font-black uppercase">
                <span className="text-blue-500">{item.categories[0] || 'Utama'}</span>
                <span className="text-gray-400 flex items-center gap-1"><Clock size={8}/> {new Date(item.pubDate).toLocaleDateString()}</span>
              </div>
            </a>
          ))
        )}
      </div>
    </div>
  );
};

// --- ANNOUNCEMENT WIDGET ---
const CommunityAnnouncements = () => {
  const announcements = [
    { title: 'Iuran Kas Januari', date: 'Deadline 31 Jan', icon: '💰', color: 'bg-emerald-50 text-emerald-700' },
    { title: 'Jadwal Fogging', date: 'Minggu Depan', icon: '💨', color: 'bg-rose-50 text-rose-700' }
  ];

  return (
    <div className="bg-white p-6 rounded-[2.5rem] shadow-lg border border-gray-100">
      <h3 className="font-black text-gray-800 uppercase text-xs tracking-widest mb-6 flex items-center gap-2">
        <Bell size={16} className="text-orange-500" /> Pengumuman
      </h3>
      <div className="space-y-3">
        {announcements.map((item, i) => (
          <div key={i} className={`p-4 rounded-2xl border-none ${item.color} flex items-center gap-4`}>
            <span className="text-xl">{item.icon}</span>
            <div>
              <h4 className="font-bold text-xs">{item.title}</h4>
              <p className="text-[9px] font-black uppercase opacity-60">{item.date}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- MAIN BLOG COMPONENT ---
export const Blog = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [name, setName] = useState('');
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: comments, isLoading, refetch } = useQuery({ 
    queryKey: ['comments'], 
    queryFn: fetchComments 
  });

  const mutation = useMutation({
    mutationFn: () => createComment(name, content),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['comments'] });
      setName(''); setContent(''); setIsSubmitting(false);
      alert('✅ Berhasil dikirim!');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: deleteComment,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['comments'] });
      alert('🗑️ Terhapus.');
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || content.length < 5) return alert('Lengkapi data!');
    setIsSubmitting(true);
    mutation.mutate();
  };

  return (
    <div className="space-y-6 px-3 md:px-6 pb-24 max-w-7xl mx-auto">
      {/* HEADER SECTION */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 py-6">
        <div className="text-center md:text-left">
          <h1 className="text-3xl md:text-5xl font-black text-emerald-950 uppercase tracking-tighter">Beryl Forum</h1>
          <p className="text-gray-500 font-bold text-sm">Pusat Informasi & Aspirasi Warga</p>
        </div>
        <div className={`px-5 py-2 rounded-full text-[10px] font-black uppercase tracking-widest ${!user ? 'bg-gray-100 text-gray-400' : 'bg-emerald-100 text-emerald-700'}`}>
          {!user ? <><EyeOff size={12} className="inline mr-1" /> Mode Tamu</> : <><Shield size={12} className="inline mr-1" /> Mode Admin</>}
        </div>
      </div>

      {/* WEATHER WIDGET */}
      <WeatherWidget />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-[2.5rem] shadow-xl border border-gray-50">
            <h3 className="font-black text-gray-800 uppercase text-xs tracking-widest mb-6 flex items-center gap-2">
              <MessageSquare size={16} className="text-emerald-500"/> Kirim Aspirasi
            </h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input 
                type="text" placeholder="Nama / Blok..." 
                className="w-full bg-gray-50 border-none p-4 rounded-2xl focus:ring-2 focus:ring-emerald-500 font-bold text-xs"
                value={name} onChange={(e) => setName(e.target.value)} required
              />
              <textarea 
                rows={4} placeholder="Tulis aspirasi anda di sini..." 
                className="w-full bg-gray-50 border-none p-4 rounded-2xl focus:ring-2 focus:ring-emerald-500 font-bold text-xs resize-none"
                value={content} onChange={(e) => setContent(e.target.value)} required
              />
              <button 
                type="submit" disabled={isSubmitting}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 uppercase text-[10px] tracking-widest"
              >
                {isSubmitting ? <Loader2 size={16} className="animate-spin" /> : <><Send size={14} /> Kirim Sekarang</>}
              </button>
            </form>
          </div>
          <NewsWidget />
          <CommunityAnnouncements />
        </div>

        {/* RIGHT COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="font-black text-gray-800 uppercase text-xs tracking-widest">Suara Warga</h3>
            <button onClick={() => refetch()} className="p-2 bg-white rounded-full shadow-sm"><RefreshCw size={14}/></button>
          </div>

          {isLoading ? (
            <div className="p-20 text-center font-black text-gray-200 animate-pulse uppercase tracking-[0.3em]">Memuat Aspirasi...</div>
          ) : (
            <div className="space-y-4 max-h-[900px] overflow-y-auto custom-scrollbar pr-1">
              {comments?.map((c: any) => (
                <div key={c.id} className="bg-white p-5 rounded-[2rem] shadow-md border border-gray-50 group transition-all">
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600 shrink-0 font-black">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-black text-emerald-900 uppercase text-xs">{c.name}</h4>
                          <span className="text-[8px] font-bold text-gray-300 uppercase italic">
                            {new Date(c.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
                          </span>
                        </div>
                        {user && (
                          <button onClick={() => confirm('Hapus?') && deleteMutation.mutate(c.id)} className="text-gray-200 hover:text-rose-500 transition-colors">
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>
                      <div className="mt-3 text-gray-600 text-xs leading-relaxed font-medium bg-gray-50/50 p-4 rounded-2xl border border-gray-100">
                        {c.content}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <style>
        {`
          .custom-scrollbar::-webkit-scrollbar { width: 4px; }
          .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
          .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        `}
      </style>
    </div>
  );
};

export default Blog;