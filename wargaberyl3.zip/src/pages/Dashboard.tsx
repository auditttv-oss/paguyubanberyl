import React, { useState, useMemo } from 'react';
import { useQuery, keepPreviousData } from '@tanstack/react-query'; // Import keepPreviousData
import { 
  fetchResidents, 
  fetchExpenses, 
  fetchAllPayments, 
  fetchPaymentsByMonth, 
  exportDataToExcel, 
  exportDataToJSON, 
  analyzeFinancesWithAI 
} from '../services/dataService';
import { useAuth } from '../contexts/AuthContext';
import { 
  Users, Wallet, Loader2, BarChart3, 
  AlertCircle, Filter, PiggyBank, Gift, Target, 
  BrainCircuit, FileSpreadsheet, FileJson, 
  CreditCard
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer 
} from 'recharts';

// --- TYPES & INTERFACES ---
interface Expense {
  id: string;
  amount: number;
  category: 'Operasional' | 'Acara' | 'Lainnya';
  date: string;
  description: string;
}

interface Payment {
  id: string;
  resident_id: string;
  amount: number;
  month: number;
  year: number;
}

interface Resident {
  id: string;
  fullName: string;
  blockNumber: string;
  eventDuesAmount?: number;
}

// --- HELPER FUNCTIONS ---
const getMonthName = (monthNumber: number): string => {
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  return months[monthNumber - 1] || 'Tidak Valid';
};

const formatCurrency = (amount: number) => {
  return `Rp ${amount.toLocaleString('id-ID')}`;
};

const getYearOptions = () => {
  const currentYear = new Date().getFullYear();
  return Array.from({ length: 5 }, (_, i) => currentYear - 2 + i);
};

// --- REUSABLE UI COMPONENTS ---
const StatusBadge = ({ status, text }: { status: 'sehat' | 'aman' | 'bahaya' | 'tersedia' | 'kosong', text: string }) => {
  const colors = {
    sehat: 'bg-green-100 text-green-800',
    tersedia: 'bg-green-100 text-green-800',
    aman: 'bg-yellow-100 text-yellow-800',
    bahaya: 'bg-red-100 text-red-800',
    kosong: 'bg-red-100 text-red-800',
  };

  return (
    <span className={`px-2 py-1 text-xs rounded-full font-bold ${colors[status] || colors.aman}`}>
      {text}
    </span>
  );
};

const StatCard = ({ 
  title, value, subValue, icon: Icon, gradient, footer 
}: { 
  title: string; value: string; subValue?: React.ReactNode; icon: any; gradient: string; footer?: React.ReactNode 
}) => (
  <div className={`bg-gradient-to-br ${gradient} text-white p-6 rounded-2xl shadow-lg`}>
    <div className="flex items-center justify-between mb-4">
      <div>
        <p className="text-sm opacity-90 mb-1 font-medium">{title}</p>
        <p className="text-3xl font-black tracking-tight">{value}</p>
      </div>
      <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
        <Icon size={24} />
      </div>
    </div>
    {subValue && <div className="text-sm opacity-80 space-y-1">{subValue}</div>}
    {footer && <div className="mt-3">{footer}</div>}
  </div>
);

// --- CUSTOM HOOK FOR LOGIC ---
const useFinancialStats = (
  residents: Resident[], 
  allExpenses: Expense[], 
  allPayments: Payment[], 
  selectedMonth: number, 
  selectedYear: number,
  monthlyPayments: Payment[]
) => {
  return useMemo(() => {
    // 1. Filter Data Dasar
    const filteredExpenses = allExpenses.filter(e => {
      const d = new Date(e.date);
      return d.getMonth() + 1 === selectedMonth && d.getFullYear() === selectedYear;
    });

    // 2. Statistik Warga & Pembayaran Bulan Ini
    const totalWarga = residents.length;
    // const paidIds = new Set(monthlyPayments.map(p => p.resident_id)); // Unused variable removed
    const paidCount = monthlyPayments.length;
    const paymentRate = totalWarga > 0 ? Math.round((paidCount / totalWarga) * 100) : 0;
    
    // Income bulan terpilih
    const incomeThisMonth = monthlyPayments.reduce((sum, p) => sum + (p.amount || 10000), 0);

    // 3. KAS BULANAN (Operasional) - Global
    const totalKasBulanan = allPayments.reduce((sum, p) => sum + (p.amount || 10000), 0);
    const totalOpsExpenses = allExpenses
      .filter(e => ['Operasional', 'Lainnya'].includes(e.category))
      .reduce((sum, e) => sum + (e.amount || 0), 0);
    const saldoKasBulanan = totalKasBulanan - totalOpsExpenses;

    // Expenses bulan terpilih (Operasional)
    const opsExpenseThisMonth = filteredExpenses
      .filter(e => ['Operasional', 'Lainnya'].includes(e.category))
      .reduce((sum, e) => sum + (e.amount || 0), 0);

    // 4. KAS ACARA (Sukarela) - Global
    const totalKasAcara = residents.reduce((sum, r) => sum + (r.eventDuesAmount || 0), 0);
    const totalEventExpenses = allExpenses
      .filter(e => e.category === 'Acara')
      .reduce((sum, e) => sum + (e.amount || 0), 0);
    const saldoKasAcara = totalKasAcara - totalEventExpenses;

    // 5. Statistik Bulanan (Chart Data)
    const monthlyStats = Array.from({ length: 12 }, (_, i) => {
      const m = i + 1;
      const income = allPayments
        .filter(p => p.month === m && p.year === selectedYear)
        .reduce((sum, p) => sum + (p.amount || 10000), 0);
      
      const expense = allExpenses
        .filter(e => {
          const d = new Date(e.date);
          return d.getMonth() + 1 === m && d.getFullYear() === selectedYear;
        })
        .reduce((sum, e) => sum + (e.amount || 0), 0);

      return {
        bulan: getMonthName(m).substring(0, 3),
        pemasukan: income,
        pengeluaran: expense,
        saldo: income - expense,
        monthNumber: m,
        isSelected: m === selectedMonth
      };
    });

    return {
      overview: {
        totalWarga,
        paidCount,
        paymentRate,
        totalPemasukan: totalKasBulanan + totalKasAcara,
        totalPengeluaran: totalOpsExpenses + totalEventExpenses,
        saldoAkhir: saldoKasBulanan + saldoKasAcara
      },
      kasBulanan: {
        total: totalKasBulanan,
        masukBulanIni: incomeThisMonth,
        keluarBulanIni: opsExpenseThisMonth, // Operasional bulan ini
        totalKeluar: totalOpsExpenses,
        saldo: saldoKasBulanan,
        status: saldoKasBulanan > 0 ? 'sehat' : saldoKasBulanan === 0 ? 'aman' : 'bahaya'
      },
      kasAcara: {
        total: totalKasAcara,
        keluar: totalEventExpenses,
        saldo: saldoKasAcara,
        status: saldoKasAcara > 0 ? 'tersedia' : saldoKasAcara === 0 ? 'aman' : 'kosong'
      },
      chartData: monthlyStats,
      raw: {
        filteredExpenses
      }
    };
  }, [residents, allExpenses, allPayments, selectedMonth, selectedYear, monthlyPayments]);
};

// --- MAIN COMPONENT ---
export const Dashboard = () => {
  const { user } = useAuth();
  
  // State
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [showMonthFilter, setShowMonthFilter] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'kas-bulanan' | 'kas-acara'>('overview');

  // Queries
  const { data: residents = [], isLoading: loadResidents, error: errResidents } = useQuery({ 
    queryKey: ['residents'], queryFn: fetchResidents 
  });
  const { data: allExpenses = [], isLoading: loadExpenses, error: errExpenses } = useQuery({ 
    queryKey: ['expenses'], queryFn: fetchExpenses 
  });
  const { data: allPayments = [], isLoading: loadAllPay, error: errAllPay } = useQuery({ 
    queryKey: ['allPayments'], queryFn: fetchAllPayments 
  });
  const { data: monthlyPayments = [], isLoading: loadMonthlyPay, error: errMonthlyPay } = useQuery({ 
    queryKey: ['payments', selectedMonth, selectedYear], 
    queryFn: () => fetchPaymentsByMonth(selectedMonth, selectedYear),
    placeholderData: keepPreviousData // FIX: Menggunakan placeholderData dari TanStack Query v5
  });

  const isLoading = loadResidents || loadExpenses || loadAllPay || loadMonthlyPay;
  const hasError = errResidents || errExpenses || errAllPay || errMonthlyPay;

  // Use Custom Hook for Logic
  const stats = useFinancialStats(
    residents as Resident[], 
    allExpenses as Expense[], 
    allPayments as Payment[], 
    selectedMonth, 
    selectedYear, 
    monthlyPayments as Payment[]
  );

  // Handlers
  const handleAI = async () => {
    setLoadingAi(true);
    try {
      const summary = `
        **DATA KEUANGAN PAGUYUBAN BERYL - ${getMonthName(selectedMonth)} ${selectedYear}**
        - Total Warga: ${stats.overview.totalWarga} KK (${stats.overview.paymentRate}% lunas)
        - Saldo Kas Bulanan (Wajib): ${formatCurrency(stats.kasBulanan.saldo)} (Status: ${stats.kasBulanan.status})
        - Saldo Kas Acara (Sukarela): ${formatCurrency(stats.kasAcara.saldo)}
        - Total Saldo Real: ${formatCurrency(stats.overview.saldoAkhir)}
        - Pemasukan Bulan Ini: ${formatCurrency(stats.kasBulanan.masukBulanIni)}
        - Pengeluaran Operasional Bulan Ini: ${formatCurrency(stats.kasBulanan.keluarBulanIni)}
      `;
      const res = await analyzeFinancesWithAI(summary);
      setAiAnalysis(res);
    } catch (error) {
      setAiAnalysis('⚠️ **Gagal menganalisis.** Coba lagi nanti.');
    } finally {
      setLoadingAi(false);
    }
  };

  // Render Loading
  if (isLoading) {
    return (
      <div className="flex flex-col justify-center items-center min-h-[400px] gap-4">
        <Loader2 className="animate-spin text-emerald-600" size={40} />
        <p className="text-gray-500 font-medium animate-pulse">Sinkronisasi data keuangan...</p>
      </div>
    );
  }

  // Render Error
  if (hasError) {
    return (
      <div className="p-8 flex justify-center">
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-6 max-w-md text-center">
          <AlertCircle className="text-rose-600 mx-auto mb-3" size={32} />
          <h3 className="text-lg font-bold text-rose-800">Gagal Memuat Data</h3>
          <p className="text-rose-600 text-sm mt-2">Terjadi kesalahan koneksi ke database.</p>
          <button onClick={() => window.location.reload()} className="mt-4 px-4 py-2 bg-rose-600 text-white rounded-lg text-sm hover:bg-rose-700">Muat Ulang</button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* --- HEADER --- */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-gray-800 tracking-tight">Dashboard Keuangan</h2>
          <p className="text-gray-500 mt-1">
            Ringkasan data per <span className="font-semibold text-emerald-600">{getMonthName(selectedMonth)} {selectedYear}</span>
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          {/* Month Filter Button */}
          <div className="relative">
            <button
              onClick={() => setShowMonthFilter(!showMonthFilter)}
              className="flex items-center gap-2 bg-white hover:bg-gray-50 text-gray-700 px-4 py-2.5 rounded-xl border border-gray-200 shadow-sm transition-all"
            >
              <Filter size={16} />
              <span className="font-medium">{getMonthName(selectedMonth)} {selectedYear}</span>
            </button>
            
            {showMonthFilter && (
              <div className="absolute top-full right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 p-4 z-50 w-72 animate-in zoom-in-50 duration-200">
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Tahun</label>
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {getYearOptions().map(year => (
                        <button
                          key={year}
                          onClick={() => setSelectedYear(year)}
                          className={`px-3 py-1.5 text-sm rounded-lg border ${selectedYear === year ? 'bg-emerald-600 text-white border-emerald-600' : 'hover:bg-gray-50'}`}
                        >
                          {year}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-400 uppercase mb-2 block">Bulan</label>
                    <div className="grid grid-cols-3 gap-2">
                      {Array.from({length: 12}, (_, i) => i+1).map(m => (
                        <button
                          key={m}
                          onClick={() => { setSelectedMonth(m); setShowMonthFilter(false); }}
                          className={`py-1.5 text-xs rounded-md transition-colors ${selectedMonth === m ? 'bg-emerald-100 text-emerald-700 font-bold' : 'hover:bg-gray-50 text-gray-600'}`}
                        >
                          {getMonthName(m).substring(0, 3)}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {user && (
            <>
              <button onClick={exportDataToExcel} className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl flex items-center gap-2 text-sm font-bold shadow-sm transition-colors">
                <FileSpreadsheet size={16} /> Excel
              </button>
              <button onClick={exportDataToJSON} className="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2.5 rounded-xl flex items-center gap-2 text-sm font-bold shadow-sm transition-colors">
                <FileJson size={16} /> Backup
              </button>
            </>
          )}
        </div>
      </div>

      {/* --- TABS --- */}
      <div className="bg-white p-1 rounded-xl border border-gray-200 inline-flex w-full md:w-auto">
        {['overview', 'kas-bulanan', 'kas-acara'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`flex-1 md:flex-none px-6 py-2 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === tab ? 'bg-emerald-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-50'
            }`}
          >
            {tab === 'overview' && <BarChart3 size={16} />}
            {tab === 'kas-bulanan' && <PiggyBank size={16} />}
            {tab === 'kas-acara' && <Gift size={16} />}
            <span className="capitalize">{tab.replace('-', ' ')}</span>
          </button>
        ))}
      </div>

      {/* --- TAB CONTENT: OVERVIEW --- */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              title="Total Warga"
              value={`${stats.overview.totalWarga} KK`}
              icon={Users}
              gradient="from-blue-500 to-blue-600"
              subValue={
                <div className="mt-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span>Lunas: {stats.overview.paidCount}</span>
                    <span>{stats.overview.paymentRate}%</span>
                  </div>
                  <div className="w-full bg-blue-400/30 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-white h-full rounded-full" style={{ width: `${stats.overview.paymentRate}%` }} />
                  </div>
                </div>
              }
            />
            <StatCard
              title="Total Saldo"
              value={formatCurrency(stats.overview.saldoAkhir)}
              icon={Wallet}
              gradient="from-emerald-500 to-emerald-600"
              subValue={
                <>
                  <div className="flex justify-between"><span>Masuk:</span> <span>{formatCurrency(stats.overview.totalPemasukan)}</span></div>
                  <div className="flex justify-between"><span>Keluar:</span> <span>{formatCurrency(stats.overview.totalPengeluaran)}</span></div>
                </>
              }
            />
            <StatCard
              title="Kas Bulanan"
              value={formatCurrency(stats.kasBulanan.saldo)}
              icon={CreditCard}
              gradient="from-purple-500 to-purple-600"
              subValue={<span className="text-xs">Dana Operasional & Sosial</span>}
              footer={<StatusBadge status={stats.kasBulanan.status as any} text={stats.kasBulanan.status === 'sehat' ? 'Sehat' : 'Perlu Perhatian'} />}
            />
            <StatCard
              title="Kas Acara"
              value={formatCurrency(stats.kasAcara.saldo)}
              icon={Gift}
              gradient="from-pink-500 to-pink-600"
              subValue={<span className="text-xs">Dana Sukarela</span>}
              footer={<StatusBadge status={stats.kasAcara.status as any} text={stats.kasAcara.status === 'tersedia' ? 'Tersedia' : 'Kosong'} />}
            />
          </div>

          {/* AI Analysis Section */}
          <div className="bg-gray-900 text-white rounded-2xl p-6 shadow-xl overflow-hidden relative">
            <div className="absolute top-0 right-0 p-3 opacity-10"><BrainCircuit size={100} /></div>
            <div className="flex justify-between items-center mb-4 relative z-10">
              <h3 className="font-bold flex items-center gap-2 text-emerald-400">
                <BrainCircuit size={20} /> Analisis Keuangan AI
              </h3>
              <button 
                onClick={handleAI} 
                disabled={loadingAi}
                className="text-xs bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-full transition disabled:opacity-50"
              >
                {loadingAi ? 'Menganalisa...' : 'Analisa Sekarang'}
              </button>
            </div>
            
            <div className="bg-white/5 rounded-xl p-4 min-h-[120px] max-h-[300px] overflow-y-auto border border-white/10 text-sm leading-relaxed">
              {aiAnalysis ? (
                <div dangerouslySetInnerHTML={{ 
                  __html: aiAnalysis
                    .replace(/\*\*(.*?)\*\*/g, '<strong class="text-emerald-300">$1</strong>')
                    .replace(/\n/g, '<br>') 
                }} />
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-gray-400 gap-2 py-4">
                  <BrainCircuit size={24} className="opacity-50" />
                  <p>Minta AI untuk menganalisa kesehatan kas bulan {getMonthName(selectedMonth)}.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* --- TAB CONTENT: KAS BULANAN --- */}
      {activeTab === 'kas-bulanan' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-6">
             {/* Detail Kas Card */}
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                <PiggyBank className="text-purple-600" size={20} /> Detail Kas Bulanan
              </h3>
              <div className="space-y-4">
                 <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                    <span className="text-gray-600">Total Masuk (YTD)</span>
                    <span className="font-bold text-purple-700">{formatCurrency(stats.kasBulanan.total)}</span>
                 </div>
                 <div className="flex justify-between items-center p-3 bg-rose-50 rounded-lg">
                    <span className="text-gray-600">Total Operasional (YTD)</span>
                    <span className="font-bold text-rose-700">{formatCurrency(stats.kasBulanan.totalKeluar)}</span>
                 </div>
                 <div className="flex justify-between items-center p-4 bg-gray-900 text-white rounded-xl shadow-lg mt-4">
                    <span className="opacity-90">Sisa Saldo</span>
                    <span className="font-black text-2xl text-emerald-400">{formatCurrency(stats.kasBulanan.saldo)}</span>
                 </div>
              </div>
            </div>

            {/* List Pengeluaran Operasional */}
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                <h3 className="font-bold text-gray-800 mb-4">Pengeluaran Operasional ({getMonthName(selectedMonth)})</h3>
                {stats.raw.filteredExpenses.filter(e => e.category !== 'Acara').length > 0 ? (
                  <div className="space-y-3">
                    {stats.raw.filteredExpenses
                      .filter(e => e.category !== 'Acara')
                      .map(e => (
                      <div key={e.id} className="flex justify-between items-start border-b border-gray-100 pb-2 last:border-0">
                        <div>
                          <p className="font-medium text-gray-800">{e.description}</p>
                          <p className="text-xs text-gray-500">{new Date(e.date).toLocaleDateString('id-ID')}</p>
                        </div>
                        <span className="font-bold text-rose-600">{formatCurrency(e.amount)}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-gray-400 py-4 italic">Tidak ada pengeluaran operasional bulan ini.</p>
                )}
            </div>
          </div>

          {/* Chart Section */}
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm h-full">
            <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
              <BarChart3 size={20} /> Tren Arus Kas {selectedYear}
            </h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="bulan" fontSize={11} stroke="#9ca3af" tickLine={false} axisLine={false} />
                  <YAxis fontSize={11} stroke="#9ca3af" tickLine={false} axisLine={false} tickFormatter={(val) => `${val/1000}k`} />
                  <Tooltip 
                    cursor={{ fill: '#f3f4f6' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    formatter={(value: number) => formatCurrency(value)}
                  />
                  <Bar dataKey="pemasukan" name="Masuk" fill="#8b5cf6" radius={[4, 4, 0, 0]} barSize={20} />
                  <Bar dataKey="pengeluaran" name="Keluar" fill="#f43f5e" radius={[4, 4, 0, 0]} barSize={20} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* --- TAB CONTENT: KAS ACARA --- */}
      {activeTab === 'kas-acara' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
           <div className="bg-gradient-to-br from-pink-500 to-pink-600 text-white p-8 rounded-3xl shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-3 bg-white/20 rounded-2xl"><Gift size={32} /></div>
                  <h3 className="text-2xl font-black">Kas Sukarela</h3>
                </div>
                <p className="opacity-90 text-lg mb-8">
                  Dana yang terkumpul dari sumbangan sukarela warga untuk kegiatan paguyuban.
                </p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-white/20 pb-2">
                    <span>Total Terkumpul</span>
                    <span className="font-bold text-xl">{formatCurrency(stats.kasAcara.total)}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/20 pb-2">
                    <span>Total Digunakan</span>
                    <span className="font-bold text-xl">{formatCurrency(stats.kasAcara.keluar)}</span>
                  </div>
                </div>
              </div>
              <div className="mt-8 pt-6 border-t border-white/20">
                 <p className="text-sm opacity-70 mb-1">Saldo Tersedia</p>
                 <p className="text-5xl font-black tracking-tighter">{formatCurrency(stats.kasAcara.saldo)}</p>
              </div>
           </div>

           <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col h-full">
              <h3 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                 <Target size={20} className="text-pink-600" /> Donatur Terbesar
              </h3>
              <div className="overflow-y-auto flex-1 pr-2">
                {residents
                  .filter(r => (r.eventDuesAmount || 0) > 0)
                  .sort((a, b) => (b.eventDuesAmount || 0) - (a.eventDuesAmount || 0))
                  .slice(0, 5)
                  .map((r, i) => (
                    <div key={r.id} className="flex items-center justify-between p-3 mb-2 rounded-xl bg-gray-50 hover:bg-pink-50 transition-colors">
                      <div className="flex items-center gap-3">
                         <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${i === 0 ? 'bg-yellow-400 text-yellow-900' : 'bg-gray-200 text-gray-700'}`}>
                           {i + 1}
                         </div>
                         <div>
                           <p className="font-bold text-gray-800">{r.fullName}</p>
                           <p className="text-xs text-gray-500">Blok {r.blockNumber}</p>
                         </div>
                      </div>
                      <span className="font-bold text-pink-600">{formatCurrency(r.eventDuesAmount || 0)}</span>
                    </div>
                  ))}
                  {residents.filter(r => (r.eventDuesAmount || 0) > 0).length === 0 && (
                    <div className="text-center text-gray-400 py-10">Belum ada donatur acara.</div>
                  )}
              </div>
           </div>
        </div>
      )}

      <div className="text-center text-xs text-gray-400 py-6 mt-8 border-t border-gray-100">
        &copy; {new Date().getFullYear()} Paguyuban Cluster Beryl. All rights reserved.
      </div>
    </div>
  );
};